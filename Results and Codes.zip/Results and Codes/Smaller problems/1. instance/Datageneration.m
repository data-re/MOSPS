%veriler

%npt number of product types [3-5]
%w number of worker
%t=[8 13];
%t number of tasks
%nb=3;
%nb seru lara atanabilecek maksimum �al��an say�s�n� g�steriyor.
%ab=[100 300]
%ab lot sizes
%s number of seru


%alttaki 1 olunca lot splitting e izin verilmiyor anlam�na geliyor
%K
numberofbatchineachlot=[1 2 4 6];

%L
numberoflot=[8 8 8 8 8 8 8 8 8 12 12 12 12 12 12 12 12 12 16 16 16 16 16 16 16 16 16];

zzz=4;
numberofbatch1=numberofbatchineachlot(zzz)*numberoflot;

numberofbatch1s4=numberofbatchineachlot(1)*numberoflot;
numberofbatch1s3=numberofbatchineachlot(2)*numberoflot;
numberofbatch1s2=numberofbatchineachlot(3)*numberoflot;
numberofbatch1s1=numberofbatchineachlot(4)*numberoflot;
%zzz hangi alt parti say�s�n�n uygulanaca��n� g�steriyor

w1=[6 6 6 8 8 8 10 10 10 6 6 6 8 8 8 10 10 10 6 6 6 8 8 8 10 10 10];

s1=[2 4 6 2 4 6 2 4 6 2 4 6 2 4 6 2 4 6 2 4 6 2 4 6 2 4 6];


for i=1:27
    t1(i)=randi(5)+8;
end

st1=zeros(sum(numberofbatch1),max(t1));
tut(1)=1;

tut1(1)=1;
wskisitli=zeros(sum(w1),max(t1))+1;
for i=1:27
    npt(i)=randi(3)+2;
    pts=randi(11,npt(i),t1(i))+9;
    pts(randperm(npt(i)*t1(i),t1(i)))=0;
    bpt=randi(npt(i),numberofbatch1(i),1);
    st1(tut(i):tut(i)+numberofbatch1(i)-1,1:t1(i))=pts(bpt,:);
    tut(i+1)=tut(i)+numberofbatch1(i);
    %wskisitli matrisi �al��anlar�n atama yap�lamayaca�� yerleri g�rmek i�in
    %olu�turuluyor
    wskisitli(tut1(i):tut1(i)+npt(i)-1,1:t1(i)) = pts;
    tut1(i+1)=tut1(i)+w1(i);
end

%tut yerine tuts1 kullan�lacak, tut1 standart olarak kal�yor zaten
numberofbatch1=numberofbatchineachlot(1)*numberoflot;
tuts4(1)=1;
for i=1:27
    tuts4(i+1)=tuts4(i)+numberofbatch1(i);
end
numberofbatch1=numberofbatchineachlot(2)*numberoflot;
tuts3(1)=1;
for i=1:27
    tuts3(i+1)=tuts3(i)+numberofbatch1(i);
end
numberofbatch1=numberofbatchineachlot(3)*numberoflot;
tuts2(1)=1;
for i=1:27
    tuts2(i+1)=tuts2(i)+numberofbatch1(i);
end
numberofbatch1=numberofbatchineachlot(4)*numberoflot;
tuts1(1)=1;
for i=1:27
    tuts1(i+1)=tuts1(i)+numberofbatch1(i);
end

zzz=4;
%numberofsublot=6
for i=1:sum(numberoflot)
    for j=1:numberofbatchineachlot(zzz)
        stt1((i-1)*numberofbatchineachlot(zzz)+j,:)=st1((i-1)*numberofbatchineachlot(zzz)+1,:);
    end
end

%numberofsublot=4
for i=1:sum(numberoflot)
    for j=1:numberofbatchineachlot(3)
        stt2((i-1)*numberofbatchineachlot(3)+j,:)=st1((i-1)*numberofbatchineachlot(4)+1,:);
    end
end

%numberofsublot=2
for i=1:sum(numberoflot)
    for j=1:numberofbatchineachlot(2)
        stt3((i-1)*numberofbatchineachlot(2)+j,:)=st1((i-1)*numberofbatchineachlot(4)+1,:);
    end
end

%numberofsublot=1
for i=1:sum(numberoflot)
    for j=1:numberofbatchineachlot(1)
        stt4((i-1)*numberofbatchineachlot(1)+j,:)=st1((i-1)*numberofbatchineachlot(4)+1,:);
    end
end


for i=1:27
    %ab1(tut(i):tut(i)+numberofbatch1(i)-1,1)=randi(21,numberofbatch1(i),1)+19;
    ab1(tut(i):tut(i)+numberofbatch1(i)-1,1)=12*(randi(3,numberofbatch1(i),1)+1);
end

%alttaki equal sublot methodology numberofsublot=6
zzz=4;
for i=1:(size(st1,1)/numberofbatchineachlot(zzz))
    for j=1:numberofbatchineachlot(zzz)
        ab1e((i-1)*numberofbatchineachlot(zzz)+j,1)=ab1((i-1)*numberofbatchineachlot(zzz)+1,1);
    end
end

%alttaki variable sublot methodology numberofsublot=6
for i=1:(size(st1,1)/numberofbatchineachlot(zzz))
    hh=randi(ab1e((i-1)*numberofbatchineachlot(zzz)+1,:),numberofbatchineachlot(zzz)-1,1);
    hh1=ab1e((i-1)*numberofbatchineachlot(zzz)+1,1)*numberofbatchineachlot(zzz)-sum(hh);
    hh2=[hh; hh1];
    ab1v((i-1)*numberofbatchineachlot(zzz)+1:i*numberofbatchineachlot(zzz),1)=hh2;
end

%alttaki equal sublot methodologynumberofsublot=4
for i=1:sum(numberoflot)
    for j=1:numberofbatchineachlot(3)
        ab2e((i-1)*numberofbatchineachlot(3)+j,:)=ab1e((i-1)*numberofbatchineachlot(4)+1,:);
    end
end
ab2e=round(ab2e*1.5);

%alttaki variable sublot methodology numberofsublot=4
for i=1:sum(numberoflot)
    hh=randi(ab2e((i-1)*numberofbatchineachlot(3)+1,:),numberofbatchineachlot(3)-1,1);
    hh1=ab2e((i-1)*numberofbatchineachlot(3)+1,1)*numberofbatchineachlot(3)-sum(hh);
    hh2=[hh; hh1];
    ab2v((i-1)*numberofbatchineachlot(3)+1:i*numberofbatchineachlot(3),1)=hh2;
end

%alttaki equal sublot methodologynumberofsublot=2
for i=1:sum(numberoflot)
    for j=1:numberofbatchineachlot(2)
        ab3e((i-1)*numberofbatchineachlot(2)+j,:)=ab1e((i-1)*numberofbatchineachlot(4)+1,:);
    end
end
ab3e=ab3e*3;
%alttaki variable sublot methodology numberofsublot=2
for i=1:sum(numberoflot)
    hh=randi(ab3e((i-1)*numberofbatchineachlot(2)+1,:),numberofbatchineachlot(2)-1,1);
    hh1=ab3e((i-1)*numberofbatchineachlot(2)+1,1)*numberofbatchineachlot(2)-sum(hh);
    hh2=[hh; hh1];
    ab3v((i-1)*numberofbatchineachlot(2)+1:i*numberofbatchineachlot(2),1)=hh2;
end

%alttaki equal sublot methodologynumberofsublot=1
for i=1:sum(numberoflot)
    for j=1:numberofbatchineachlot(1)
        ab4e((i-1)*numberofbatchineachlot(1)+j,:)=ab1e((i-1)*numberofbatchineachlot(4)+1,:);
    end
end
ab4e=ab4e*6;
%alttaki variable sublot methodology numberofsublot=1
for i=1:sum(numberoflot)
    hh=randi(ab4e((i-1)*numberofbatchineachlot(1)+1,:),numberofbatchineachlot(1)-1,1);
    hh1=ab4e((i-1)*numberofbatchineachlot(1)+1,1)*numberofbatchineachlot(1)-sum(hh);
    hh2=[hh; hh1];
    ab4v((i-1)*numberofbatchineachlot(1)+1:i*numberofbatchineachlot(1),1)=hh2;
end




%Alltaki ws1,2,3 senaryo 1 ve 2 i�in kullan�l�yor.
ws1=zeros(sum(w1),max(t1));
for i=1:27
    %  ws1(tut1(i):tut1(i)+w1(i)-1,1:t1(i)) = 0.5 + (1.5-0.5).*rand(w1(i),t1(i));
    ws1(tut1(i):tut1(i)+w1(i)-1,1:t1(i))=1;
end

ws2=zeros(sum(w1),max(t1));
for i=1:27
    %   ws2(tut1(i):tut1(i)+w1(i)-1,1:t1(i)) = 0.8 + (1.2-0.8).*rand(w1(i),t1(i));
    ws2(tut1(i):tut1(i)+w1(i)-1,1:t1(i)) =1;
end

ws3=zeros(sum(w1),max(t1));
for i=1:27
    ws3(tut1(i):tut1(i)+w1(i)-1,1:t1(i)) = 1;
end

ws11(:,:,1)=ws1;
ws11(:,:,2)=ws2;
ws11(:,:,3)=ws3;

