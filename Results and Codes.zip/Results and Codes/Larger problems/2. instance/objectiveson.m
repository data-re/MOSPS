%objective ama� fonksiyonu makespan idi average flow time oldu
function [ tutobje ] = objectiveson( numberofbatch,population,population_size,nb,ws,st,t,s)
for hk=1:population_size
    chr=population(:,:,hk);
    for i=1:numberofbatch
        if (chr(i,5)==1)
            p(i)=st(i,chr(i,6+nb+nb:6+nb+nb+t-1))*ws(chr(i,6),chr(i,6+nb+nb:6+nb+nb+t-1))';
        else
            p1=zeros(1,nb);
            p1(1)=st(i,chr(i,6+nb+nb:6+nb+nb+chr(i,6+nb)-1))*ws(chr(i,6),chr(i,6+nb+nb:6+nb+nb+chr(i,6+nb)-1))';
            for j=2:chr(i,5)
                p1(j)=st(i,chr(i,6+nb+nb+chr(i,4+nb+j):6+nb+nb+chr(i,5+nb+j)-1))*ws(chr(i,5+j),chr(i,6+nb+nb+chr(i,4+nb+j):6+nb+nb+chr(i,5+nb+j)-1))';
            end
            p(i)=max(p1);
        end
        f(i)=p(i)*chr(i,3);
        wsub(1,1:t)=1.5;
        wslb=0.5;
        pub(i)=st(i,chr(i,6+nb+nb:6+nb+nb+t-1))*wsub';
        plb(i)=max(st(i,chr(i,6+nb+nb:6+nb+nb+t-1))*wslb);
        fub(i)=pub(i)*chr(i,3);
        flb(i)=plb(i)*chr(i,3);
    end
    ub=sum(fub);
    lb=sum(flb)/s;
    matris=zeros(numberofbatch,4+nb);
    matris(:,3)=f';
    matris(:,4)=chr(:,4);
    matris(:,5:5+nb-1)=chr(:,6:5+nb);
    tut=sortrows(chr(:,1:2),2);
    set1=tut(:,1)';
    set2=set1(1,1);
    matris(set1(1),2)=f(set1(1));
    for i=2:numberofbatch
        k=max(matris(find(matris(:,4)==matris(set1(i),4)),2));
        l1=find(matris(:,2)>k);
        A=matris(l1,5:end);
        B=matris(set1(i),5:end);
        flags = arrayfun(@(a) bsxfun(@(x,y) any(eq(x,y) & x > 0),B,a), A);
        indexToDesiredRows = all(any(flags,2),3);
        rowNumbers = find(indexToDesiredRows);
        l=l1(rowNumbers);
        m1=sort(matris(l,2),'ascend');
        m=[k m1'];
        A1=[m' m'+matris(set1(i),3)];
        B1=matris(l,1:2);
        BB=reshape(B1',1,2,[]);
        atanabilecek=all(bsxfun(@le,A1(:,2),BB(1,1,:)) | bsxfun(@ge,A1(:,1),BB(1,2,:)),3);
        matris(set1(i),1:2)=A1(find(atanabilecek==1,1),1:2);
        set2(i)=set1(i);
    end
    objective1(hk)=max(matris(:,2));
    %objective1=makespan
    objective2(hk)=sum(matris(:,2))/size(matris,1);
    %objective2=averageflow time
    
    A=matris(:,5:end);
    for i=1:max(max(A))
        B=i;
        flags = arrayfun(@(a) bsxfun(@(x,y) any(eq(x,y) & x > 0),B,a), A);
        indexToDesiredRows = all(any(flags,2),3);
        rowNumbers = find(indexToDesiredRows);
        workload(i,1)=sum(matris(rowNumbers,3));
    end
    objective3(hk)=max(workload)-min(workload);
    %objective3=workload imbalance
end
obje=[objective1' objective2' objective3'];
tutobje=obje;
sz1=size(obje);
obje(:,4)=zeros;
obje(:,5)=[1:sz1(1)]';
for j=1:size(obje,1)
    for i=1:sz1(1)
        obje1=obje(i,1:3);
        [C]=unique(obje(:,1:3),'rows','stable');
        dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
        obje(i,4)=sum(dominated);
    end
    tutobje(obje(find(obje(:,4)==1),5),4)=j;
    tutobje(find(tutobje(:,1)==min(tutobje(obje(find(obje(:,4)==1),5),1))),5)=-100;
    tutobje(find(tutobje(:,2)==min(tutobje(obje(find(obje(:,4)==1),5),2))),5)=-100;
    tutobje(find(tutobje(:,3)==min(tutobje(obje(find(obje(:,4)==1),5),3))),5)=-100;
    obje(find(obje(:,4)==1),:)=[];
    sz1=size(obje);
    if sz1(1)==0
        break
    end
end
end



