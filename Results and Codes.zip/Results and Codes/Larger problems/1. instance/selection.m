function [mid_population] = selection(P,pobje,population_size)

aj=(pobje(:,4).^-1)/sum((pobje(:,4).^-1));
aj1(1)=aj(1);
for i=2:population_size
     aj1(i)=aj1(i-1)+aj(i);
end

%yars�n� direkt P populasyonundan al�yor
for i=1:population_size/2
    mid_population(:,:,i)=P(:,:,i);
end

%di�er yar�s�n� rank a bakarak roulette wheel �zerinden se�iyor 
for i=(population_size/2)+1:population_size
mid_population(:,:,i)=P(:,:,find(aj1>=rand,1));
end

end