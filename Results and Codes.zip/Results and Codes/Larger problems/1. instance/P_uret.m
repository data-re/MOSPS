function [ pobje,P ] = P_uret( P,Q,pobje,qobje)
population_size=size(P,3);
R=P;
R(:,:,population_size+1:2*population_size)=[Q];

obje=[pobje;qobje];
tutobje=obje;
sz1=size(obje);
obje(:,4)=zeros;
obje(:,5)=[1:sz1(1)]';
for j=1:size(obje,1)
    for i=1:sz1(1)
        obje1=obje(i,1:3);
        [C]=unique(obje(:,1:3),'rows','stable');
        dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
        obje(i,4)=sum(dominated);
    end
    tutobje(obje(find(obje(:,4)==1),5),4)=j;
    tutobje(find(tutobje(:,1)==min(tutobje(obje(find(obje(:,4)==1),5),1))),5)=-100;
    tutobje(find(tutobje(:,2)==min(tutobje(obje(find(obje(:,4)==1),5),2))),5)=-100;
     tutobje(find(tutobje(:,3)==min(tutobje(obje(find(obje(:,4)==1),5),3))),5)=-100;
    obje(find(obje(:,4)==1),:)=[];
    sz1=size(obje);
    if sz1(1)==0
        break
    end
end
rtutobje=tutobje;
rtutobje(:,6)=[1:population_size*2]';
rtutobje=sortrows(rtutobje,[4,5]);
for i=1:population_size
    P(:,:,i)=R(:,:,rtutobje(i,6));
    pobje(i,:)=rtutobje(i,1:5);
end

end

