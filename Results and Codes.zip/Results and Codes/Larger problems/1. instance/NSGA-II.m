%genetic
function [ P,pobje,time ] = genetic(alg,w,t,nb,ab,s,ws,st,numberofbatch,population_size,crpr,mtpr,iteration_number )
%scenario1 transfer is allowed (fully-crosstrained)
%scenario2 transfer is not allowed (fully-crosstrained)
% if alg==1 || alg==2 || alg==6
%     %scenario1+random atama ba�la
%     %scenario2+random atama ba�la
%     first_population=zeros(numberofbatch,5+nb*2+t,population_size);
%     for k=1:population_size
%         chr=zeros(numberofbatch,6+nb+nb+t-1);
%         chr(:,2)=randperm(numberofbatch);
%         chr(:,3)=ab;
%         for i=1:numberofbatch
%             chr(i,1)=i;
%             chr(i,4)=randperm(s,1);
%             chr(i,5)=randperm(nb,1);
%             chr(i,6:6+chr(i,5)-1)=randperm(w,chr(i,5));
%             chr(i,6+nb:6+nb+chr(i,5)-1)=sort(randperm(t,chr(i,5)),'ascend');
%             chr(i,6+nb+chr(i,5)-1)=t;
%             chr(i,6+nb+nb:6+nb+nb+t-1)=randperm(t);
%         end
%         first_population(:,:,k)=chr;
%     end
%     %scenario1+random atama bitir
% else
    first_population=zeros(numberofbatch,5+nb*2+t,population_size);
    for k=1:population_size
        chr=zeros(numberofbatch,6+nb+nb+t-1);
        chr(:,2)=randperm(numberofbatch);
        chr(:,3)=ab;
        for i=1:numberofbatch
            chr(i,1)=i;
            chr(i,4)=randperm(s,1);
            chr(i,5)=randperm(nb,1);
            chr(i,6:6+chr(i,5)-1)=randperm(w,chr(i,5));
            chr(i,6+nb:6+nb+chr(i,5)-1)=sort(randperm(t,chr(i,5)),'ascend');
            chr(i,6+nb+chr(i,5)-1)=t;
            chr(i,6+nb+nb:6+nb+nb+t-1)=randperm(t);
        end
        %%{
        if (s>=3)
            z1=round(numberofbatch/s);
            chr(1:z1,4)=1;
            for i=2:s-1
                chr((i-1)*z1+1:i*z1,4)=i;
            end
            chr((s-1)*z1+1:end,4)=s;
        end

        if(s==2)
            chr(1:(numberofbatch/2),4)=1;
            chr((numberofbatch/2)+1:numberofbatch,4)=2;
        end

        z2=floor(w/s);
        if (z2==0)
            z2=1;
        end
        if (z2>nb)
            z2=nb;
        end
        chr(:,5)=z2;
        if((w>z2*s)&(z2<nb))
            for i=1:(w-z2*s)
                chr(chr(:,4)==chr(find(chr(:,5)<nb,1),4),5)=chr(chr(:,4)==chr(find(chr(:,5)<nb,1),4),5)+1;
            end
        end

        chr(:,6:6+nb-1)=0;
        for i=1:numberofbatch
            chr(i,6:6+chr(i,5)-1)=randperm(w,chr(i,5));
        end
        %}

        %%{
        ajh=randperm(w);
        chr(:,6:6+nb-1)=0;
        tuf(1)=chr(find(chr(:,4)==1,1),5);
        chr(chr(:,4)==1,6:6+tuf(1)-1)=bsxfun(@plus,chr(chr(:,4)==1,6:6+tuf(1)-1),ajh(1:+tuf(1)));
        tuff=tuf(1);
        for j=2:s
            tuf(j)=chr(find(chr(:,4)==j,1),5);
            chr(chr(:,4)==j,6:6+tuf(j)-1)=bsxfun(@plus,chr(chr(:,4)==j,6:6+tuf(j)-1),ajh(tuff+1:tuff+tuf(j)));
            tuff=tuf(j)+tuff;
        end
        %}
        %bir �stteki �al��anlar�n h�creler aras� ge�i� yapmad���,her h�creye e�it say�da olmak �zere farkl� �al��anlar atan�yor ve ge�i� yapam�yorlar.
        % %{
        for i=1:numberofbatch
            chr(i,6+nb:6+nb+chr(i,5)-1)=sort(randperm(t,chr(i,5)),'ascend');
            chr(i,6+nb+chr(i,5)-1)=t;
            chr(i,6+nb+nb:6+nb+nb+t-1)=randperm(t);
        end
        %}
        %scenario2+random atama bitir
        first_population(:,:,k)=chr;
    end
% end
population=first_population;
[ tutobje ] = objectiveson( numberofbatch,population,population_size,nb,ws,st,t,s);
P=population;
pobje=tutobje;
d=1;
asda=clock;
while(d<iteration_number)
    [mid_population] = selection(P,pobje,population_size);
    [ Q ] = crossover(alg,mid_population,population_size,nb,t,numberofbatch,crpr,mtpr);
    population=Q;
    [ tutobje ] = objectiveson( numberofbatch,population,population_size,nb,ws,st,t,s);
    qobje=tutobje;
    [ pobje,P ] = P_uret( P,Q,pobje,qobje);
    d=d+1;
end
time=etime(clock,asda);

end

