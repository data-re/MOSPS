%run
%alg farkl� algoritmalar� ifade ediyor
% (i)	Worker transfer is allowed + lot splitting is allowed+ equal sublots
% (ii)	Worker transfer is allowed + lot splitting is allowed+ consistent/variable sublots
% (iii)	Worker transfer is not allowed + lot splitting is allowed+ equal sublots
% (iv)	Worker transfer is not allowed + lot splitting is allowed+ consistent/variable sublots
% (v)	Worker transfer is not allowed + lot splitting is not allowed
% (vi)	Worker transfer is allowed + lot splitting is not allowed
%i problem t�rleri
%k numberofsublots in each lot [2 4 6]

%RUN SONUCU ELDE ED�LECEKLER "tum_sonuclar, Cmetrik,Dmetrik, OSmetrik,Nndmetrik"

for alg=1:6
    for k=1:3
        for i=1:9
            w=w1(i);
            t=t1(i);
            nb=4;
            s=s1(i);
            ws=ws11(tut1(i):tut1(i)+w1(i)-1,1:t1(i),1);
            % numberofbatch=numberofbatch1(i);
            % st=st1(tut(i):tut(i)+numberofbatch1(i)-1,1:t1(i));
            % ab=ab1(tut(i):tut(i)+numberofbatch1(i)-1,1);
            if alg==1 && k==1
                numberofbatch1=numberofbatch1s3;
                numberofbatch=numberofbatch1(i);
                tut=tuts3;
                st1=stt3;
                ab1=ab3e;
                st=st1(tut(i):tut(i)+numberofbatch1(i)-1,1:t1(i));
                ab=ab1(tut(i):tut(i)+numberofbatch1(i)-1,1);
            elseif  alg==1 && k==2
                numberofbatch1=numberofbatch1s2;
                numberofbatch=numberofbatch1(i);
                tut=tuts2;
                st1=stt2;
                ab1=ab2e;
                st=st1(tut(i):tut(i)+numberofbatch1(i)-1,1:t1(i));
                ab=ab1(tut(i):tut(i)+numberofbatch1(i)-1,1);
            elseif  alg==1 && k==3
                numberofbatch1=numberofbatch1s1;
                numberofbatch=numberofbatch1(i);
                tut=tuts1;
                st1=stt1;
                ab1=ab1e;
                st=st1(tut(i):tut(i)+numberofbatch1(i)-1,1:t1(i));
                ab=ab1(tut(i):tut(i)+numberofbatch1(i)-1,1);
            elseif alg==2 && k==1
                numberofbatch1=numberofbatch1s3;
                numberofbatch=numberofbatch1(i);
                tut=tuts3;
                st1=stt3;
                ab1=ab3v;
                st=st1(tut(i):tut(i)+numberofbatch1(i)-1,1:t1(i));
                ab=ab1(tut(i):tut(i)+numberofbatch1(i)-1,1);
            elseif  alg==2 && k==2
                numberofbatch1=numberofbatch1s2;
                numberofbatch=numberofbatch1(i);
                tut=tuts2;
                st1=stt2;
                ab1=ab2v;
                st=st1(tut(i):tut(i)+numberofbatch1(i)-1,1:t1(i));
                ab=ab1(tut(i):tut(i)+numberofbatch1(i)-1,1);
            elseif  alg==2 && k==3
                numberofbatch1=numberofbatch1s1;
                numberofbatch=numberofbatch1(i);
                tut=tuts1;
                st1=stt1;
                ab1=ab1v;
                st=st1(tut(i):tut(i)+numberofbatch1(i)-1,1:t1(i));
                ab=ab1(tut(i):tut(i)+numberofbatch1(i)-1,1);
            elseif alg==3 && k==1
                numberofbatch1=numberofbatch1s3;
                numberofbatch=numberofbatch1(i);
                tut=tuts3;
                st1=stt3;
                ab1=ab3e;
                st=st1(tut(i):tut(i)+numberofbatch1(i)-1,1:t1(i));
                ab=ab1(tut(i):tut(i)+numberofbatch1(i)-1,1);
            elseif  alg==3 && k==2
                numberofbatch1=numberofbatch1s2;
                numberofbatch=numberofbatch1(i);
                tut=tuts2;
                st1=stt2;
                ab1=ab2e;
                st=st1(tut(i):tut(i)+numberofbatch1(i)-1,1:t1(i));
                ab=ab1(tut(i):tut(i)+numberofbatch1(i)-1,1);
            elseif  alg==3 && k==3
                numberofbatch1=numberofbatch1s1;
                numberofbatch=numberofbatch1(i);
                tut=tuts1;
                st1=stt1;
                ab1=ab1e;
                st=st1(tut(i):tut(i)+numberofbatch1(i)-1,1:t1(i));
                ab=ab1(tut(i):tut(i)+numberofbatch1(i)-1,1);
            elseif alg==4 && k==1
                numberofbatch1=numberofbatch1s3;
                numberofbatch=numberofbatch1(i);
                tut=tuts3;
                st1=stt3;
                ab1=ab3v;
                st=st1(tut(i):tut(i)+numberofbatch1(i)-1,1:t1(i));
                ab=ab1(tut(i):tut(i)+numberofbatch1(i)-1,1);
            elseif  alg==4 && k==2
                numberofbatch1=numberofbatch1s2;
                numberofbatch=numberofbatch1(i);
                tut=tuts2;
                st1=stt2;
                ab1=ab2v;
                st=st1(tut(i):tut(i)+numberofbatch1(i)-1,1:t1(i));
                ab=ab1(tut(i):tut(i)+numberofbatch1(i)-1,1);
            elseif  alg==4 && k==3
                numberofbatch1=numberofbatch1s1;
                numberofbatch=numberofbatch1(i);
                tut=tuts1;
                st1=stt1;
                ab1=ab1v;
                st=st1(tut(i):tut(i)+numberofbatch1(i)-1,1:t1(i));
                ab=ab1(tut(i):tut(i)+numberofbatch1(i)-1,1);
            elseif alg==5
                numberofbatch1=numberofbatch1s4;
                numberofbatch=numberofbatch1(i);
                tut=tuts4;
                st1=stt4;
                ab1=ab4v;
                st=st1(tut(i):tut(i)+numberofbatch1(i)-1,1:t1(i));
                ab=ab1(tut(i):tut(i)+numberofbatch1(i)-1,1);
            elseif alg==6
                numberofbatch1=numberofbatch1s4;
                numberofbatch=numberofbatch1(i);
                tut=tuts4;
                st1=stt4;
                ab1=ab4v;
                st=st1(tut(i):tut(i)+numberofbatch1(i)-1,1:t1(i));
                ab=ab1(tut(i):tut(i)+numberofbatch1(i)-1,1);
            end
            iteration_number=5;
            population_size=4;
            [P,pobje,time ] = genetic(alg,w,t,nb,ab,s,ws,st,numberofbatch,population_size,0.9,0.1,iteration_number);
            
           
            tum_sonuclar((population_size*(i-1)+1):population_size*i,(k-1)*5+1:k*5,alg)=pobje;
            
            %tum_sonuclar her algoritmadan elde edilen en son P nin fitness function de�erlerini tutuyor 
            %a�a�� do�ru t�m P populasyonuna kar��l�k gelen de�erler yer
            %al�yor t�m problemler i�in t�m de�erler a�a�� do�ru yer al�yor
            %yani 27*population_size kadar sat�r var. sa�a do�ru da k
            %de�erleri kadar tekrarlan�yor. pobje population_size*5
            %boyutunda ancak son iki sutun ama� fonksiyon de�erlerini
            %tutmuyor
 
            %Pareto front �izdirilmek istendi�inde tumsonuclar dosyas�ndan
            %ilgili problem i�in rank=1 olanlar bulunup �izdirilmeli
            
            CPU(i,k,alg)=time;
        end
    end
end

%�stteki senaryo 1 ve 2 i�in 3 ws1,2,3 i�in �al��t�r�lmal�
%Ayr�ca convergence grafikleri oralar i�in
%koyulmal�.

for kk=1:3
    for ii=1:9  
            %yukar�daki pobjenin son iki sut�n� ama� fonksiyon de�eri tutmuyor bu
            %nedenle tum_sonuclar�n son iki sutunu dikkate al�nm�yor ve
            %��kar�larak yeni pobje de�erleri hesaplan�yor
            pobje1=tum_sonuclar((ii-1)*population_size+find(tum_sonuclar(population_size*(ii-1)+1:population_size*ii,5*kk-1,1)==1),(kk-1)*5+1:kk*5-2,1);
            pobje2=tum_sonuclar((ii-1)*population_size+find(tum_sonuclar(population_size*(ii-1)+1:population_size*ii,5*kk-1,2)==1),(kk-1)*5+1:kk*5-2,2);
            pobje3=tum_sonuclar((ii-1)*population_size+find(tum_sonuclar(population_size*(ii-1)+1:population_size*ii,5*kk-1,3)==1),(kk-1)*5+1:kk*5-2,3);
            pobje4=tum_sonuclar((ii-1)*population_size+find(tum_sonuclar(population_size*(ii-1)+1:population_size*ii,5*kk-1,4)==1),(kk-1)*5+1:kk*5-2,4);
            pobje5=tum_sonuclar((ii-1)*population_size+find(tum_sonuclar(population_size*(ii-1)+1:population_size*ii,5*kk-1,5)==1),(kk-1)*5+1:kk*5-2,5);
            pobje6=tum_sonuclar((ii-1)*population_size+find(tum_sonuclar(population_size*(ii-1)+1:population_size*ii,5*kk-1,6)==1),(kk-1)*5+1:kk*5-2,6);
                
           
            %d12
            C=pobje1;
            obje=pobje2;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d12=size(ak,1)/size(obje,1);
            
            %d21
            c1=C;
            o1=obje;
            obje=c1;
            C=o1;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d21=size(ak,1)/size(obje,1);
            
             %d13
            C=pobje1;
            obje=pobje3;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d13=size(ak,1)/size(obje,1);
                   
             %d31
            c1=C;
            o1=obje;
            obje=c1;
            C=o1;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d31=size(ak,1)/size(obje,1);
            
             %d14
            C=pobje1;
            obje=pobje4;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d14=size(ak,1)/size(obje,1);
            
             %d41
            c1=C;
            o1=obje;
            obje=c1;
            C=o1;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d41=size(ak,1)/size(obje,1);
            
            %d15
            C=pobje1;
            obje=pobje5;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d15=size(ak,1)/size(obje,1);
            
             %d51
            c1=C;
            o1=obje;
            obje=c1;
            C=o1;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d51=size(ak,1)/size(obje,1);
            
            %d16
            C=pobje1;
            obje=pobje6;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d16=size(ak,1)/size(obje,1);
            
             %d61
            c1=C;
            o1=obje;
            obje=c1;
            C=o1;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d61=size(ak,1)/size(obje,1);
            
             %d23
            C=pobje2;
            obje=pobje3;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d23=size(ak,1)/size(obje,1);
            
            %d32
            c1=C;
            o1=obje;
            obje=c1;
            C=o1;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d32=size(ak,1)/size(obje,1);
            
            %d24
            C=pobje2;
            obje=pobje4;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d24=size(ak,1)/size(obje,1);
            
            %d42
            c1=C;
            o1=obje;
            obje=c1;
            C=o1;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d42=size(ak,1)/size(obje,1);
            
            %d25
            C=pobje2;
            obje=pobje5;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d25=size(ak,1)/size(obje,1);
            
            %d52
            c1=C;
            o1=obje;
            obje=c1;
            C=o1;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d52=size(ak,1)/size(obje,1);
            
            %d26
            C=pobje2;
            obje=pobje6;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d26=size(ak,1)/size(obje,1);
            
            %d62
            c1=C;
            o1=obje;
            obje=c1;
            C=o1;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d62=size(ak,1)/size(obje,1);
            
            %d34
            C=pobje3;
            obje=pobje4;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d34=size(ak,1)/size(obje,1);
            
            %d43
            c1=C;
            o1=obje;
            obje=c1;
            C=o1;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d43=size(ak,1)/size(obje,1);
            
            %d35
            C=pobje3;
            obje=pobje5;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d35=size(ak,1)/size(obje,1);
            
            %d53
            c1=C;
            o1=obje;
            obje=c1;
            C=o1;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d53=size(ak,1)/size(obje,1);
            
              %d36
            C=pobje3;
            obje=pobje6;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d36=size(ak,1)/size(obje,1);
            
            %d63
            c1=C;
            o1=obje;
            obje=c1;
            C=o1;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d63=size(ak,1)/size(obje,1);
            
               %d45
            C=pobje4;
            obje=pobje5;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d45=size(ak,1)/size(obje,1);
            
            %d54
            c1=C;
            o1=obje;
            obje=c1;
            C=o1;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d54=size(ak,1)/size(obje,1);
            
            %d46
            C=pobje4;
            obje=pobje6;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d46=size(ak,1)/size(obje,1);
            
            %d64
            c1=C;
            o1=obje;
            obje=c1;
            C=o1;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d64=size(ak,1)/size(obje,1);
            
             %d56
            C=pobje5;
            obje=pobje6;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d56=size(ak,1)/size(obje,1);
            
            %d65 6. ve 5. algoritmalar�n c metri�i �zerinden
            %kar��la�t�r�lmalar�. Bu simetrik olmad��� i�in hem 5-6 hem 6-5
            %e bak�l�yor
            c1=C;
            o1=obje;
            obje=c1;
            C=o1;
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)>0);
            size(ak,1);
            d65=size(ak,1)/size(obje,1);
            
            Cmet=[1 d12 d13 d14 d15 d16; d21 1 d23 d24 d25 d26; d31 d32 1 d34 d35 d36; d41 d42 d43 1 d45 d46; d51 d52 d53 d54 1 d56; d61 d62 d63 d64 d65 1];
            Cmetrik((ii-1)*6+1:ii*6,(kk-1)*6+1:kk*6)=Cmet;
            %Cmetrik de�erleri her problem i�in t�m algoritmalar�n
            %kar��la�t�r�lmas� ile yap�l�yor toplamda 27 problem tipi var
            %ve her k (number of sublots a lot can be split) i�in yana
            %do�ru uzuyor sonu� olarak 27 (problem t�r�) problemin herbiri
            %i�in 6*6 kar��la�t�rma yap�lacak ve bunlar  k n�n her seviyesi
            %i�in (toplamda 3) tekrarlanacak. Sonu� olarak 27*6, 3*6 l�k
            %bir matris oluyor. Matrisde kar��la�t�rma de�erlerinin nas�l
            %yer alaca�� Cmet de g�z�k�yor
            
            
            
            %alttaki dr hesabı yapıyor
            % cozum1 ve cozum2 iki farklı algoritmadan elde edilen pareto frontlar
            % bunları birşeştirerek ortak S frontu elde ediliyor. Daha fazla front da
            % birleştirilebilir.
            cozum1=pobje1;
            cozum2=pobje2;
            cozum3=pobje3;
            cozum4=pobje4;
            cozum5=pobje5;
            cozum6=pobje6;
            
            obje=[cozum1;cozum2;cozum3;cozum4;cozum5;cozum6];
            sz1=size(obje);
            for i=1:sz1(1)
                obje1=obje(i,1:3);
                [C]=unique(obje(:,1:3),'rows','stable');
                dominated=all(bsxfun(@ge,obje1(1,1),C(:,1)) & bsxfun(@ge,obje1(1,2),C(:,2)) & bsxfun(@ge,obje1(1,3),C(:,3)),3);
                obje(i,4)=sum(dominated);
            end
            ak=find(obje(:,4)==1);
            S=obje(ak,1:3);
            ssz=size(S);
            %alttaki cozum1 ve cozum2 esasında kaç front hesaplıyorsak o kadar uzayacak
            ssz1=size(cozum1);
            for i=1:ssz(1)
                for k=1:ssz1(1)
                    tut(k)=(((S(i,1)-cozum1(k,1))/(max(S(:,1))-min(S(:,1))))^2)+(((S(i,2)-cozum1(k,2))/(max(S(:,2))-min(S(:,2))))^2)+(((S(i,3)-cozum1(k,3))/(max(S(:,3))-min(S(:,3))))^2);
                end
                dr(i)=min(tut);
            end
            drr1=sum(dr)/ssz(1);
            dr=[];
            tut=[];
            ssz1=size(cozum2);
            for i=1:ssz(1)
                for k=1:ssz1(1)
                    tut(k)=(((S(i,1)-cozum2(k,1))/(max(S(:,1))-min(S(:,1))))^2)+(((S(i,2)-cozum2(k,2))/(max(S(:,2))-min(S(:,2))))^2)+(((S(i,3)-cozum2(k,3))/(max(S(:,3))-min(S(:,3))))^2);
                end
                dr(i)=min(tut);
            end
            drr2=sum(dr)/ssz(1);
            dr=[];
            tut=[];
            ssz1=size(cozum3);
            for i=1:ssz(1)
                for k=1:ssz1(1)
                    tut(k)=(((S(i,1)-cozum3(k,1))/(max(S(:,1))-min(S(:,1))))^2)+(((S(i,2)-cozum3(k,2))/(max(S(:,2))-min(S(:,2))))^2)+(((S(i,3)-cozum3(k,3))/(max(S(:,3))-min(S(:,3))))^2);
                end
                dr(i)=min(tut);
            end
            drr3=sum(dr)/ssz(1);
            dr=[];
            tut=[];
            ssz1=size(cozum4);
            for i=1:ssz(1)
                for k=1:ssz1(1)
                    tut(k)=(((S(i,1)-cozum4(k,1))/(max(S(:,1))-min(S(:,1))))^2)+(((S(i,2)-cozum4(k,2))/(max(S(:,2))-min(S(:,2))))^2)+(((S(i,3)-cozum4(k,3))/(max(S(:,3))-min(S(:,3))))^2);
                end
                dr(i)=min(tut);
            end
            drr4=sum(dr)/ssz(1);
            
            dr=[];
            tut=[];
            ssz1=size(cozum5);
            for i=1:ssz(1)
                for k=1:ssz1(1)
                    tut(k)=(((S(i,1)-cozum5(k,1))/(max(S(:,1))-min(S(:,1))))^2)+(((S(i,2)-cozum5(k,2))/(max(S(:,2))-min(S(:,2))))^2)+(((S(i,3)-cozum5(k,3))/(max(S(:,3))-min(S(:,3))))^2);
                end
                dr(i)=min(tut);
            end
            drr5=sum(dr)/ssz(1);
            
            dr=[];
            tut=[];
            ssz1=size(cozum6);
            for i=1:ssz(1)
                for k=1:ssz1(1)
                    tut(k)=(((S(i,1)-cozum6(k,1))/(max(S(:,1))-min(S(:,1))))^2)+(((S(i,2)-cozum6(k,2))/(max(S(:,2))-min(S(:,2))))^2)+(((S(i,3)-cozum6(k,3))/(max(S(:,3))-min(S(:,3))))^2);
                end
                dr(i)=min(tut);
            end
            drr6=sum(dr)/ssz(1);
            
            dmet=[drr1 drr2 drr3 drr4 drr5 drr6];
            Dmetrik(ii,(kk-1)*6+1:kk*6)=dmet;
            
            %dmetrik de�erleri her sat�rda farkl� bir problemin (27) ��z�m�
            %tutuluyor her sut�n bir algoritmaya kar��l�k geliyor ve yana
            %do�ru k(3) kadar uzuyor. k=1, 2, 3
            
            %alttaki iki farklı front karşılaştırılmasında kullanılıyor tüm ikililer
            %için gerçekleştirilecek
            
            OS12=((max(cozum1(:,1))-min(cozum1(:,1)))*(max(cozum1(:,2))-min(cozum1(:,2)))*(max(cozum1(:,3))-min(cozum1(:,3)))+0.5)/((max(cozum2(:,1))-min(cozum2(:,1)))*(max(cozum2(:,2))-min(cozum2(:,2)))*(max(cozum2(:,3))-min(cozum2(:,3)))+0.5);
            
            OS13=((max(cozum1(:,1))-min(cozum1(:,1)))*(max(cozum1(:,2))-min(cozum1(:,2)))*(max(cozum1(:,3))-min(cozum1(:,3)))+0.5)/((max(cozum3(:,1))-min(cozum3(:,1)))*(max(cozum3(:,2))-min(cozum3(:,2)))*(max(cozum3(:,3))-min(cozum3(:,3)))+0.5);
            
            OS14=((max(cozum1(:,1))-min(cozum1(:,1)))*(max(cozum1(:,2))-min(cozum1(:,2)))*(max(cozum1(:,3))-min(cozum1(:,3)))+0.5)/((max(cozum4(:,1))-min(cozum4(:,1)))*(max(cozum4(:,2))-min(cozum4(:,2)))*(max(cozum4(:,3))-min(cozum4(:,3)))+0.5);
            
            OS15=((max(cozum1(:,1))-min(cozum1(:,1)))*(max(cozum1(:,2))-min(cozum1(:,2)))*(max(cozum1(:,3))-min(cozum1(:,3)))+0.5)/((max(cozum5(:,1))-min(cozum5(:,1)))*(max(cozum5(:,2))-min(cozum5(:,2)))*(max(cozum5(:,3))-min(cozum5(:,3)))+0.5);

            OS16=((max(cozum1(:,1))-min(cozum1(:,1)))*(max(cozum1(:,2))-min(cozum1(:,2)))*(max(cozum1(:,3))-min(cozum1(:,3)))+0.5)/((max(cozum6(:,1))-min(cozum6(:,1)))*(max(cozum6(:,2))-min(cozum6(:,2)))*(max(cozum6(:,3))-min(cozum6(:,3)))+0.5);
            
            OS23=((max(cozum2(:,1))-min(cozum2(:,1)))*(max(cozum2(:,2))-min(cozum2(:,2)))*(max(cozum2(:,3))-min(cozum2(:,3)))+0.5)/((max(cozum3(:,1))-min(cozum3(:,1)))*(max(cozum3(:,2))-min(cozum3(:,2)))*(max(cozum3(:,3))-min(cozum3(:,3)))+0.5);
            
            OS24=((max(cozum2(:,1))-min(cozum2(:,1)))*(max(cozum2(:,2))-min(cozum2(:,2)))*(max(cozum2(:,3))-min(cozum2(:,3)))+0.5)/((max(cozum4(:,1))-min(cozum4(:,1)))*(max(cozum4(:,2))-min(cozum4(:,2)))*(max(cozum4(:,3))-min(cozum4(:,3)))+0.5);
            
            OS25=((max(cozum2(:,1))-min(cozum2(:,1)))*(max(cozum2(:,2))-min(cozum2(:,2)))*(max(cozum2(:,3))-min(cozum2(:,3)))+0.5)/((max(cozum5(:,1))-min(cozum5(:,1)))*(max(cozum5(:,2))-min(cozum5(:,2)))*(max(cozum5(:,3))-min(cozum5(:,3)))+0.5);
            
            OS26=((max(cozum2(:,1))-min(cozum2(:,1)))*(max(cozum2(:,2))-min(cozum2(:,2)))*(max(cozum2(:,3))-min(cozum2(:,3)))+0.5)/((max(cozum6(:,1))-min(cozum6(:,1)))*(max(cozum6(:,2))-min(cozum6(:,2)))*(max(cozum6(:,3))-min(cozum6(:,3)))+0.5);
            
            OS34=((max(cozum3(:,1))-min(cozum3(:,1)))*(max(cozum3(:,2))-min(cozum3(:,2)))*(max(cozum3(:,3))-min(cozum3(:,3)))+0.5)/((max(cozum4(:,1))-min(cozum4(:,1)))*(max(cozum4(:,2))-min(cozum4(:,2)))*(max(cozum4(:,3))-min(cozum4(:,3)))+0.5);
            
            OS35=((max(cozum3(:,1))-min(cozum3(:,1)))*(max(cozum3(:,2))-min(cozum3(:,2)))*(max(cozum3(:,3))-min(cozum3(:,3)))+0.5)/((max(cozum5(:,1))-min(cozum5(:,1)))*(max(cozum5(:,2))-min(cozum5(:,2)))*(max(cozum5(:,3))-min(cozum5(:,3)))+0.5);

            OS36=((max(cozum3(:,1))-min(cozum3(:,1)))*(max(cozum3(:,2))-min(cozum3(:,2)))*(max(cozum3(:,3))-min(cozum3(:,3)))+0.5)/((max(cozum6(:,1))-min(cozum6(:,1)))*(max(cozum6(:,2))-min(cozum6(:,2)))*(max(cozum6(:,3))-min(cozum6(:,3)))+0.5);
            
            OS45=((max(cozum4(:,1))-min(cozum4(:,1)))*(max(cozum4(:,2))-min(cozum4(:,2)))*(max(cozum4(:,3))-min(cozum4(:,3)))+0.5)/((max(cozum5(:,1))-min(cozum5(:,1)))*(max(cozum5(:,2))-min(cozum5(:,2)))*(max(cozum5(:,3))-min(cozum5(:,3)))+0.5);
          
            OS46=((max(cozum4(:,1))-min(cozum4(:,1)))*(max(cozum4(:,2))-min(cozum4(:,2)))*(max(cozum4(:,3))-min(cozum4(:,3)))+0.5)/((max(cozum6(:,1))-min(cozum6(:,1)))*(max(cozum6(:,2))-min(cozum6(:,2)))*(max(cozum6(:,3))-min(cozum6(:,3)))+0.5);

            OS56=((max(cozum5(:,1))-min(cozum5(:,1)))*(max(cozum5(:,2))-min(cozum5(:,2)))*(max(cozum5(:,3))-min(cozum5(:,3)))+0.5)/((max(cozum6(:,1))-min(cozum6(:,1)))*(max(cozum6(:,2))-min(cozum6(:,2)))*(max(cozum6(:,3))-min(cozum6(:,3)))+0.5);
            
            osmet=[OS12 OS13 OS14 OS15 OS16 OS23 OS24 OS25 OS26 OS34 OS35 OS36 OS45 OS46 OS56];
            
            OSmetrik(ii,(kk-1)*15+1:kk*15)=osmet;
            
            %OSmetrik de�erleri her sat�rda farkl� bir problemin (27) ��z�m�
            %tutuluyor her sut�n bir algoritmaya kar��l�k geliyor ve yana
            %do�ru k(3) kadar uzuyor. k=1, 2, 3 (her k da 15 tane OSmetrik
            %de�eri var
            %bu simetrik oldu�u i�in ikili kar��la�t�rmalar tek y�nl� olsa
            %yetiyor.
            
            Nnd1=size(pobje1,1);
            Nnd2=size(pobje2,1);
            Nnd3=size(pobje3,1);
            Nnd4=size(pobje4,1);
            Nnd5=size(pobje5,1);
            Nnd6=size(pobje6,1);
            
            Nndmet1=size(unique(pobje1(:,1:3),'rows','stable'),1);
            Nndmet2=size(unique(pobje2(:,1:3),'rows','stable'),1);
            Nndmet3=size(unique(pobje3(:,1:3),'rows','stable'),1);
            Nndmet4=size(unique(pobje4(:,1:3),'rows','stable'),1);
            Nndmet5=size(unique(pobje5(:,1:3),'rows','stable'),1);
            Nndmet6=size(unique(pobje6(:,1:3),'rows','stable'),1);
            
            Nndmet=[Nndmet1 Nndmet2 Nndmet3 Nndmet4 Nndmet5 Nndmet6];
            Nndmetrik(ii,(kk-1)*6+1:kk*6)=Nndmet;
            %Nndmetrik de�erleri her sat�rda farkl� bir problemin (27) ��z�m�
            %tutuluyor her sut�n bir algoritmaya kar��l�k geliyor ve yana
            %do�ru k(3) kadar uzuyor. k=1, 2, 3 (her k i�in 6 de�er
            %tutuluyor)            
        end
    end

