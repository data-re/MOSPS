%crossovers

function [ Q ] = crossover(alg,mid_population,population_size,nb,t,numberofbatch,crpr,mtpr)

%hem selection hem croosover hem mutation hem de elitism burada yer al�yor.
%Roulettewhell selection yapt�m objective min oldu�u i�in aj de�i�keni ile
%tersini ald�m ve olas�l�k aral�kalr� belirledim, se�imi populasyondan her seferinde
%iki tane chromosome alarak yap�yor. Alaca�� kromozomlara olas�l�k
%aral�klar�ndan bakarak karar veriyor b�ylece iyi ��z�m�n olasl�k de�eri
%y�ksek oldu�u i�in se�ilme olas�l��� art�yor (Roulette whell selection). Daha sonra her iki
%kromozomdan kesim noktalar� belirliyor toplamda chromosomu kesebilece�i
%d�rt nokta var bunlardan belirleniyor. ve her ikili father mother dan
%birer adet son ve daughter �retiyor bu nedenle population_size/2 iterasyon
%yeterli oluyor. Chromosome one point �zerine kurulu JIMO paper ile bener.
%Mutasyonu ise mtpr olas�l��� yeterli gelirse crossover
%sonucu elde etti�i son ve daughter a uyguluyor. Mutasyon chromosome un son
%sat�arlar�n� yani �al��anlara atanan task lar�n s�ras�n� de�i�tiriyor.
%Hangi batch i�in mutasyon yap�aca��na da rastsal karar veriliyor.
%for d�ng�s�nden sonra bir �nceki fonksiyonda hesaplam�� oldu�u objective1
%de�erlerini kullanarak en iyi %elitism_rate say�da ��z�m� for d�ng�s�nden �nce ab de�i�keni
%vas�tas�yla tutuyor ve for d�ng�s�nden sonra mid_population �n ilk
%%elitism_rate say�daki chromosome unun yerine elitistpopulation � at�yor.
population=mid_population;
if alg==1 || alg==2 || alg==6
    mid_population=zeros(numberofbatch,5+nb*2+t,population_size);

    kes=[2 3 4 5+2*nb];
    
    %�al��an transferine izin verilmezken 4. kesim noktas�n� ��kar a�a��da da r1=randi(3) yap
    
    for t1=1:population_size/2
        tut=population(:,:,2*t1-1);
        tut1=population(:,:,2*t1);
        if (rand<crpr)
            r1=randi(4);
            tut2=[tut(:,1:kes(r1)) tut1(:,kes(r1)+1:end)];
            tut21=[tut1(:,1:kes(r1)) tut(:,kes(r1)+1:end)];
            mid_population(:,:,2*t1-1)=tut2;
            mid_population(:,:,2*t1)=tut21;
        else
            mid_population(:,:,2*t1-1)=tut;
            mid_population(:,:,2*t1)=tut1;
        end
        if (rand<mtpr)
            mid_population(randi(numberofbatch),6+2*nb:end,2*t1-1)=randperm(t);
            mid_population(randi(numberofbatch),6+2*nb:end,2*t1)=randperm(t);
        end
    end
    
else
    mid_population=zeros(numberofbatch,5+nb*2+t,population_size);
    kes=[2 3 5+2*nb];
    
    %�al��an transferine izin verilmezken 4. kesim noktas�n� ��kar a�a��da da r1=randi(3) yap
    
    for t1=1:population_size/2
        tut=population(:,:,2*t1-1);
        tut1=population(:,:,2*t1);
        if (rand<crpr)
            r1=randi(3);
            tut2=[tut(:,1:kes(r1)) tut1(:,kes(r1)+1:end)];
            tut21=[tut1(:,1:kes(r1)) tut(:,kes(r1)+1:end)];
            mid_population(:,:,2*t1-1)=tut2;
            mid_population(:,:,2*t1)=tut21;
        else
            mid_population(:,:,2*t1-1)=tut;
            mid_population(:,:,2*t1)=tut1;
        end
        if (rand<mtpr)
            mid_population(randi(numberofbatch),6+2*nb:end,2*t1-1)=randperm(t);
            mid_population(randi(numberofbatch),6+2*nb:end,2*t1)=randperm(t);
        end
    end
end
    Q=mid_population;
end

